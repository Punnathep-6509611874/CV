package com.NexusPoint.model;

import lombok.Data;

@Data
public class USER {
    String username;
    String password;
}
