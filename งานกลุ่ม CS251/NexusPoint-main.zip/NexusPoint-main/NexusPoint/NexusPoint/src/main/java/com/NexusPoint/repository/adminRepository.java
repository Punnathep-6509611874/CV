package com.NexusPoint.repository;

public interface adminRepository {
    public int insertEmployee();
}
