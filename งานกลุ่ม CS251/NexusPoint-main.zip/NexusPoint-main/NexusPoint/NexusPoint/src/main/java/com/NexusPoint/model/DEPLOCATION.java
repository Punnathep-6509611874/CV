package com.NexusPoint.model;
import lombok.Setter;
import lombok.Getter;

@Getter
@Setter
public class DEPLOCATION {
    private String depID; // FK
    private String depLocation;

}
