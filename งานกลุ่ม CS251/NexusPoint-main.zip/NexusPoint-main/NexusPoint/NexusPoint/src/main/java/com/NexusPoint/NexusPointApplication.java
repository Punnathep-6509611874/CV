package com.NexusPoint;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NexusPointApplication {

	public static void main(String[] args) {
		SpringApplication.run(NexusPointApplication.class, args);
	}

}
