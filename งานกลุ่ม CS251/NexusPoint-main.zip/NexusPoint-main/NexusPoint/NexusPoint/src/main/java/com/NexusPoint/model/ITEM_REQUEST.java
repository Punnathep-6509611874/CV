package com.NexusPoint.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ITEM_REQUEST {
    private String empID;
    private String itemID;
    private int itemAmount;
}
