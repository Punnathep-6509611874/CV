package com.NexusPoint.model;

import lombok.Setter;
import lombok.Getter;

@Getter
@Setter
public class DEPARTMENT {
    private String depID;
    private String depName;
    private String depEmpNum;

}
