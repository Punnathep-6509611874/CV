package com.NexusPoint.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ITEMPHOTO {
    private String itemID;
    private String itemPhoto;
}
