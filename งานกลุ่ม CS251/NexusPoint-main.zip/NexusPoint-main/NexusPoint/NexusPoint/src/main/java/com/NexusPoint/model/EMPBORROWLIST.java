package com.NexusPoint.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class EMPBORROWLIST extends BORROW_ITEM {
    private int penaltyAmount;
}
